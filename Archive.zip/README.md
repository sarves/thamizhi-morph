# ThamizhiMorph-all

ThamizhiMorph-all extends ThamizhiMorph with:

- compound-aware workflow (suggest -> user confirm -> admin approve),
- multi-model FST analysis (configurable, currently one verb model),
- lemma translation lookup.

## Project Layout

```text
ThamizhiMorph-all/
  backend/
    main.py
    model_manager.py
    compound_store.py
    transliterator.py
    feature_mapper.py
    translation_lexicon.py
    config/
      mapping.json
      features.json
      models.json
      lemma_translations.json
    data/
      compound_review.json
  frontend/
    index.html
    app.js
    styles.css
```

## Run Locally

```bash
cd ThamizhiMorph-all
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --host 127.0.0.1 --port 8001
```

Open `http://127.0.0.1:8001`.

## Configure Models

Edit `backend/config/models.json` and add or remove enabled models.
You can later include noun or other FST models in the same list.

```json
{
  "models": [
    {
      "id": "verb_fst",
      "label": "Tamil Verb FST",
      "enabled": true,
      "kind": "foma",
      "flookup_path": "/opt/homebrew/bin/flookup",
      "analyzer_path": "data/thamizhimorph.bin",
      "timeout_seconds": 10
    }
  ]
}
```

## Compound Workflow

1. Analyzer suggests potential compounds.
2. User confirms/edits segmentation and submits.
3. Entry is written to `backend/data/compound_review.json` with Tamil segments and generated analysis options.
4. Admin edits `selectedAnalysis` values and changes `status` from `pending` to `approved`.
5. Approved entries are reused automatically, so users are not asked again.

Example review entry:

```json
{
  "compounds": {
    "செய்யவேண்டும்": {
      "compound": "செய்யவேண்டும்",
      "status": "pending",
      "segments": [
        {
          "text": "செய்ய",
          "role": "verb",
          "selectedAnalysis": null,
          "analysisOptions": [
            {
              "index": 0,
              "lemma": "செய்",
              "analysis": "verb+nonfin+sim+sup+inf"
            }
          ]
        }
      ],
      "submittedAt": "2026-05-06T15:38:24Z",
      "approvedAt": null,
      "approvedBy": null
    }
  }
}
```

## Lemma Translation

Edit `backend/config/lemma_translations.json`:

```json
{
  "nhada": "walk",
  "cey": "do"
}
```

## Feature Mapping

Edit `backend/config/features.json` to control UD-style feature output.
