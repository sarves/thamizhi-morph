from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now(tz=timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class CompoundStore:
    def __init__(self, review_path: Path):
        self.review_path = review_path
        self._ensure_file()

    def _ensure_file(self) -> None:
        if not self.review_path.exists():
            self.review_path.parent.mkdir(parents=True, exist_ok=True)
            self._write({"compounds": {}})

    def _read(self) -> dict[str, Any]:
        with self.review_path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if "compounds" not in data:
            data["compounds"] = {}
        return data

    def _write(self, data: dict[str, Any]) -> None:
        with self.review_path.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.write("\n")

    def list_all(self) -> list[dict[str, Any]]:
        data = self._read()
        return [
            item
            for _, item in sorted(data.get("compounds", {}).items(), key=lambda pair: pair[0])
        ]

    def list_pending(self) -> list[dict[str, Any]]:
        return [item for item in self.list_all() if item.get("status") == "pending"]

    def list_approved(self) -> list[dict[str, Any]]:
        return [item for item in self.list_all() if item.get("status") == "approved"]

    def get(self, compound_tamil: str) -> dict[str, Any] | None:
        data = self._read()
        return data.get("compounds", {}).get(compound_tamil)

    def upsert_pending(
        self,
        compound_tamil: str,
        segments: list[dict[str, Any]],
    ) -> dict[str, Any]:
        data = self._read()
        existing = data.get("compounds", {}).get(compound_tamil, {})
        if existing.get("status") == "approved":
            return {"ok": False, "message": "Compound is already approved."}

        record = {
            "compound": compound_tamil,
            "status": "pending",
            "segments": segments,
            "submittedAt": existing.get("submittedAt") or now_iso(),
            "updatedAt": now_iso(),
            "approvedAt": None,
            "approvedBy": None,
        }
        data["compounds"][compound_tamil] = record
        self._write(data)
        return {"ok": True, "record": record}

    def approve(
        self,
        compound_tamil: str,
        approved_by: str = "admin",
        selected_analyses: list[int | None] | None = None,
    ) -> dict[str, Any]:
        data = self._read()
        record = data.get("compounds", {}).get(compound_tamil)
        if record is None:
            return {"ok": False, "message": f"No review entry found for {compound_tamil}."}

        if selected_analyses is not None:
            for index, selected in enumerate(selected_analyses):
                if index < len(record.get("segments", [])):
                    record["segments"][index]["selectedAnalysis"] = selected

        record["status"] = "approved"
        record["approvedAt"] = now_iso()
        record["approvedBy"] = approved_by
        record["updatedAt"] = now_iso()
        data["compounds"][compound_tamil] = record
        self._write(data)
        return {"ok": True, "approved": record}
