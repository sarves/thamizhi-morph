from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class FeatureMapper:
    def __init__(self, config_path: Path):
        self.config_path = config_path
        self.config = self._load_config(config_path)

    @staticmethod
    def _load_config(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def map_tags(self, tags: list[str]) -> dict[str, object]:
        self.config = self._load_config(self.config_path)
        features = self.config.get("features", {})
        ignore_tags = set(self.config.get("ignoreTags", []))
        unimorph: list[str] = []
        ud_pairs: dict[str, set[str]] = {}

        for tag in tags:
            if tag in ignore_tags:
                continue

            entry = features.get(tag)
            if entry is None:
                label = f"TM_{tag.upper()}"
                unimorph.extend(label.split(";"))
                ud_pairs.setdefault("ThamizhiMorph", set()).add(tag)
                continue

            label = entry.get("unimorph")
            if label:
                unimorph.extend(part for part in label.split(";") if part)

            for key, value in entry.get("ud", {}).items():
                ud_pairs.setdefault(key, set()).add(value)

        return {
            "unimorph": ";".join(self._unique(unimorph)) or "_",
            "ud": self._format_ud(ud_pairs),
        }

    @staticmethod
    def _unique(values: list[str]) -> list[str]:
        seen = set()
        unique_values = []
        for value in values:
            if value not in seen:
                seen.add(value)
                unique_values.append(value)
        return unique_values

    @staticmethod
    def _format_ud(pairs: dict[str, set[str]]) -> str:
        if not pairs:
            return "_"

        formatted = []
        for key in sorted(pairs):
            values = ",".join(sorted(pairs[key]))
            formatted.append(f"{key}={values}")
        return "|".join(formatted)

