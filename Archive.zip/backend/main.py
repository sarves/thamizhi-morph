from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .compound_store import CompoundStore
from .feature_mapper import FeatureMapper
from .model_manager import ModelManager
from .translation_lexicon import TranslationLexicon
from .transliterator import Transliterator


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
DOCS_DIR = PROJECT_ROOT / "docs"
CONFIG_DIR = PROJECT_ROOT / "backend" / "config"
DATA_DIR = PROJECT_ROOT / "backend" / "data"

transliterator = Transliterator(CONFIG_DIR / "mapping.json")
feature_mapper = FeatureMapper(CONFIG_DIR / "features.json")
model_manager = ModelManager(CONFIG_DIR / "models.json", PROJECT_ROOT)
compound_store = CompoundStore(DATA_DIR / "compound_review.json")
translation_lexicon = TranslationLexicon(CONFIG_DIR / "lemma_translations.json")

app = FastAPI(
    title="ThamizhiMorph-all",
    description="Compound-aware Tamil morphological analysis with configurable FST models.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    text: str
    inputMode: Literal["auto", "tamil", "roman"] = "auto"


class TransliterateRequest(BaseModel):
    text: str
    direction: Literal["tamil-to-roman", "roman-to-tamil"] = "tamil-to-roman"


class CompoundSubmitRequest(BaseModel):
    compound: str
    segmentation: str
    roles: str = ""
    sourceToken: str = ""
    inputMode: Literal["auto", "tamil", "roman"] = "auto"
    defaultSegmentation: str = ""


class CompoundSuggestRequest(BaseModel):
    text: str
    inputMode: Literal["auto", "tamil", "roman"] = "auto"


class CompoundApproveRequest(BaseModel):
    compound: str
    approvedBy: str = "admin"
    inputMode: Literal["auto", "tamil", "roman"] = "auto"
    selectedAnalyses: list[int | None] | None = None


TOKEN_PATTERN = re.compile(r"[\u0b80-\u0bffA-Za-zñÑ]+")
NON_LEMMA_PREFIX_TAGS = {"def"}


def tokenize(text: str) -> list[str]:
    return TOKEN_PATTERN.findall(transliterator.normalize_unicode(text))


def parse_analysis_line(line: str) -> tuple[str, str, list[str]]:
    if "\t" in line:
        _, analysis = line.split("\t", 1)
    else:
        analysis = line

    analysis = analysis.strip()
    if analysis == "+?":
        return "", "", ["?"]

    if "+" not in analysis:
        return "", analysis.strip(), []

    parts = [part.strip() for part in analysis.split("+") if part.strip()]
    if parts and parts[0].startswith("C") and len(parts) > 1:
        lemma = parts[1]
        tags = parts[2:]
    elif parts and parts[0] in NON_LEMMA_PREFIX_TAGS and len(parts) > 1:
        lemma = parts[1]
        tags = [parts[0], *parts[2:]]
    else:
        lemma = parts[0]
        tags = parts[1:]
    return "", lemma, tags


def has_known_analysis(roman_token: str, cache: dict[str, bool]) -> bool:
    if roman_token in cache:
        return cache[roman_token]

    result = model_manager.analyze_token(
        roman_token,
        transliterator.roman_to_tamil(roman_token),
        stage="exact",
    )
    known = False
    for model in result.get("models", []):
        for line in model.get("lines", []):
            _, _, tags = parse_analysis_line(line)
            if tags and tags != ["?"]:
                known = True
                break
        if known:
            break

    cache[roman_token] = known
    return known


def propose_default_segments(roman_token: str, analysis_cache: dict[str, bool]) -> list[str]:
    if len(roman_token) < 6:
        return [roman_token]

    if "-" in roman_token:
        parts = [part for part in roman_token.split("-") if part]
        if len(parts) > 1:
            return parts

    for split_point in range(2, len(roman_token) - 1):
        left = roman_token[:split_point]
        right = roman_token[split_point:]
        if has_known_analysis(left, analysis_cache) and has_known_analysis(right, analysis_cache):
            return [left, right]

    return [roman_token]


def parse_plus_list(raw: str) -> list[str]:
    return [item.strip() for item in raw.split("+") if item.strip()]


def unique_lines(lines: list[str]) -> list[str]:
    seen = set()
    output = []
    for line in lines:
        if line in seen:
            continue
        seen.add(line)
        output.append(line)
    return output


def format_compound_segments(segments: list[str], roles: list[str]) -> str:
    if not segments:
        return "-"
    output = []
    for index, segment in enumerate(segments):
        role = roles[index] if index < len(roles) else ""
        if role:
            output.append(f"{segment}({role})")
        else:
            output.append(segment)
    return " + ".join(output)


def format_segment_label(segment_roman: str, role: str = "") -> str:
    segment_tamil = transliterator.roman_to_tamil(segment_roman)
    return f"{segment_tamil} ({role})" if role else segment_tamil


def status_label(compound_status: str, has_analysis: bool) -> str:
    if compound_status == "pending":
        return "Review pending"
    if compound_status == "approved":
        return "Approved"
    if compound_status == "needs_confirmation":
        return "Needs segmentation"
    if has_analysis:
        return "Analyzed"
    return "Not found"


def normalize_lemma_value(lemma: str) -> tuple[str, str]:
    if not lemma:
        return "-", ""
    if has_tamil_text(lemma):
        return lemma, transliterator.tamil_to_roman(lemma)
    return transliterator.roman_to_tamil(lemma), lemma


def make_table_row(
    token_display: str,
    segment_display: str,
    lemma: str,
    analysis: str,
    ud_features: str,
    compound_status: str,
    has_analysis: bool,
) -> dict[str, str]:
    lemma_tamil, lemma_roman = normalize_lemma_value(lemma)
    return {
        "token": token_display,
        "segment": segment_display,
        "lemmaTamil": lemma_tamil,
        "lemmaRoman": lemma_roman or "-",
        "lemmaTranslation": translation_lexicon.get(lemma_tamil, lemma_roman) if lemma_roman else "-",
        "analysis": analysis,
        "udFeatures": ud_features,
        "status": status_label(compound_status, has_analysis),
    }


def tamil_for_review(value: str) -> str:
    if has_tamil_text(value):
        return value
    return transliterator.roman_to_tamil(value)


def has_tamil_text(value: str) -> bool:
    return transliterator.contains_tamil(value)


def best_segment_tamil(token: str, detected_mode: str, segment_roman: str, has_analysis: bool, is_compound: bool) -> str:
    if is_compound:
        return transliterator.roman_to_tamil(segment_roman)
    if detected_mode == "tamil" and has_tamil_text(token):
        return token
    if has_analysis:
        return transliterator.roman_to_tamil(segment_roman)
    return ""


def normalize_segments_to_roman(segments: list[str]) -> list[str]:
    return [transliterator.normalise_to_roman(segment, "auto")[0] for segment in segments if segment]


def normalize_segments_to_tamil(segments: list[str]) -> list[str]:
    return [tamil_for_review(segment) for segment in segments if segment]


def compound_prompt(
    token: str,
    roman_token: str,
    default_segments: list[str],
    message: str,
) -> dict[str, Any]:
    return {
        "token": tamil_for_review(token),
        "tokenRoman": roman_token,
        "defaultSegments": [tamil_for_review(segment) for segment in default_segments],
        "defaultRoles": ["part"] * len(default_segments),
        "message": message,
    }


def find_review_entry(token: str, roman_token: str, status: str | None = None) -> dict[str, Any] | None:
    token_tamil = tamil_for_review(token)
    direct = compound_store.get(token_tamil)
    if direct is not None and (status is None or direct.get("status") == status):
        return direct

    for item in compound_store.list_all():
        if status is not None and item.get("status") != status:
            continue
        compound_value = item.get("compound", "")
        compound_roman, _ = transliterator.normalise_to_roman(compound_value, "auto")
        if compound_roman == roman_token:
            return item
    return None


def analysis_options_for_segment(segment_tamil: str) -> list[dict[str, Any]]:
    segment_roman, _ = transliterator.normalise_to_roman(segment_tamil, "auto")
    result = model_manager.analyze_tokens([segment_roman], [segment_tamil])
    options: list[dict[str, Any]] = []
    seen = set()

    for model_result in result.get("models", []):
        blocks = model_result.get("blocks", [])
        lines = unique_lines(blocks[0] if blocks else [])
        for line in lines:
            _, lemma_value, tags = parse_analysis_line(line)
            has_analysis = bool(tags and tags != ["?"])
            if not has_analysis:
                continue
            analysis = "+".join(tags)
            key = (lemma_value, analysis)
            if key in seen:
                continue
            seen.add(key)
            options.append({
                "index": len(options),
                "lemma": normalize_lemma_value(lemma_value)[0],
                "analysis": analysis,
            })

    return options


def selected_stored_options(segment_record: dict[str, Any]) -> list[dict[str, Any]]:
    options = segment_record.get("analysisOptions", [])
    selected = segment_record.get("selectedAnalysis")
    if selected is None:
        return options
    return [option for option in options if option.get("index") == selected]


def row_from_stored_option(
    token_display: str,
    segment_display: str,
    option: dict[str, Any],
    compound_status: str,
) -> dict[str, str]:
    lemma_tamil = option.get("lemma", "")
    analysis = option.get("analysis", "")
    tags = [tag for tag in analysis.split("+") if tag]
    mapped = feature_mapper.map_tags(tags)
    return make_table_row(
        token_display=token_display,
        segment_display=segment_display,
        lemma=lemma_tamil,
        analysis=analysis or "Analysis not found",
        ud_features=mapped.get("ud", "_") if tags else "_",
        compound_status=compound_status,
        has_analysis=bool(tags),
    )


def rows_from_model_result(
    token: str,
    analysis_targets: list[str],
    tamil_analysis_targets: list[str],
    per_model_result: dict[str, Any],
    compound_status: str = "token",
    roles: list[str] | None = None,
    is_compound: bool = False,
) -> tuple[list[dict[str, str]], bool]:
    rows: list[dict[str, str]] = []
    roles = roles or []

    for segment_index, segment in enumerate(analysis_targets):
        segment_role = roles[segment_index] if segment_index < len(roles) else ""
        segment_display = format_segment_label(segment, segment_role) if is_compound else "-"
        token_display = token if segment_index == 0 else ""

        block_lines: list[str] = []
        for model_result in per_model_result.get("models", []):
            model_blocks = model_result.get("blocks", [])
            block_lines.extend(model_blocks[segment_index] if segment_index < len(model_blocks) else [])
        block_lines = unique_lines(block_lines)

        parsed_lines = [parse_analysis_line(line) for line in block_lines]
        has_any_analysis = any(bool(tags and tags != ["?"]) for _, _, tags in parsed_lines)
        produced_row = False

        for _, lemma_value, tags in parsed_lines:
            has_analysis = bool(tags and tags != ["?"])
            if has_any_analysis and not has_analysis:
                continue
            if not has_analysis and produced_row:
                continue

            if has_analysis:
                analysis = "+".join(tags)
                ud_features = feature_mapper.map_tags(tags).get("ud", "_")
            else:
                analysis = "Analysis not found"
                ud_features = "_"

            rows.append(make_table_row(
                token_display=token_display,
                segment_display=segment_display,
                lemma=lemma_value,
                analysis=analysis,
                ud_features=ud_features,
                compound_status=compound_status,
                has_analysis=has_analysis,
            ))
            produced_row = True
            token_display = ""

        if not produced_row:
            rows.append(make_table_row(
                token_display=token_display,
                segment_display=segment_display,
                lemma="",
                analysis="Analysis not found",
                ud_features="_",
                compound_status=compound_status,
                has_analysis=False,
            ))

    return rows, any(row.get("status") != "Not found" for row in rows)


def priority_model_passes() -> list[dict[str, Any]]:
    passes = [
        {"groups": ["verb", "noun"]},
        {"groups": ["pronoun"]},
        {"groups": ["particle"]},
        {"groups": ["adverb"]},
        {"groups": ["adjective"]},
    ]
    for model in model_manager.list_enabled_models():
        if model.get("stage") == "guesser":
            passes.append({"ids": [model.get("id", "")], "stage": "guesser"})
    return passes


def analyze_by_priority(
    token: str,
    roman_token: str,
    tamil_token: str,
) -> tuple[list[dict[str, str]], bool]:
    fallback_rows: list[dict[str, str]] = []
    for model_pass in priority_model_passes():
        result = model_manager.analyze_tokens(
            [roman_token],
            [tamil_token],
            stage=model_pass.get("stage", "exact"),
            groups=model_pass.get("groups"),
            ids=model_pass.get("ids"),
        )
        rows, has_analysis = rows_from_model_result(
            token,
            [roman_token],
            [tamil_token],
            result,
        )
        if not fallback_rows:
            fallback_rows = rows
        if has_analysis:
            return rows, True
    return fallback_rows, False


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "product": "ThamizhiMorph-all"}


@app.post("/api/transliterate")
def transliterate(payload: TransliterateRequest) -> dict[str, str]:
    text = transliterator.normalize_unicode(payload.text)
    if payload.direction == "roman-to-tamil":
        result = transliterator.roman_to_tamil(text)
    else:
        result = transliterator.tamil_to_roman(text)
    return {"result": result}


@app.get("/api/compound/pending")
def pending_compounds() -> dict[str, Any]:
    return {"pending": compound_store.list_pending()}


@app.get("/api/compound/approved")
def approved_compounds() -> dict[str, Any]:
    return {"approved": compound_store.list_approved()}


@app.post("/api/compound/submit")
def submit_compound(payload: CompoundSubmitRequest) -> dict[str, Any]:
    compound_tamil = tamil_for_review(payload.sourceToken or payload.compound)
    segments = parse_plus_list(payload.segmentation)
    roles = parse_plus_list(payload.roles)
    if not segments:
        return {"ok": False, "message": "Segmentation is required."}

    segments_tamil = normalize_segments_to_tamil(segments)
    segment_records = []
    for index, segment_tamil in enumerate(segments_tamil):
        segment_records.append({
            "text": segment_tamil,
            "role": roles[index] if index < len(roles) else "",
            "selectedAnalysis": None,
            "analysisOptions": analysis_options_for_segment(segment_tamil),
        })

    result = compound_store.upsert_pending(compound_tamil, segment_records)
    if result.get("ok"):
        result["message"] = (
            f"Segmentation stored for review: {compound_tamil}="
            f"{'+'.join(segments_tamil)}. Approve it to make it permanent."
        )
    return result


@app.post("/api/compound/suggest")
def suggest_compounds(payload: CompoundSuggestRequest) -> dict[str, Any]:
    normalized_input = transliterator.normalize_unicode(payload.text)
    source_tokens = tokenize(normalized_input)
    suggestions: list[dict[str, Any]] = []
    analysis_cache: dict[str, bool] = {}

    for token in source_tokens:
        roman_token, _ = transliterator.normalise_to_roman(token, payload.inputMode)
        entry = find_review_entry(token, roman_token)
        if entry is not None:
            suggestions.append({
                "token": tamil_for_review(token),
                "tokenRoman": roman_token,
                "status": entry.get("status", "pending"),
                "defaultSegments": [item.get("text", "") for item in entry.get("segments", [])],
                "defaultRoles": [item.get("role", "") for item in entry.get("segments", [])],
                "message": "Compound already exists in the review store.",
            })
            continue

        suggestion = propose_default_segments(roman_token, analysis_cache)
        default_segments = suggestion if len(suggestion) > 1 else [token]
        suggestions.append(
            compound_prompt(
                token,
                roman_token,
                default_segments,
                "Confirm or edit segmentation, then submit for review."
            )
        )

    return {
        "input": normalized_input,
        "tokens": source_tokens,
        "suggestions": suggestions,
    }


@app.post("/api/compound/approve")
def approve_compound(payload: CompoundApproveRequest) -> dict[str, Any]:
    compound_tamil = tamil_for_review(payload.compound)
    result = compound_store.approve(
        compound_tamil,
        approved_by=payload.approvedBy,
        selected_analyses=payload.selectedAnalyses,
    )
    if result.get("ok"):
        result["message"] = f"Approved and activated: {compound_tamil}"
    return result


@app.post("/api/analyze")
def analyze(payload: AnalyzeRequest) -> dict[str, Any]:
    normalized_input = transliterator.normalize_unicode(payload.text)
    source_tokens = tokenize(normalized_input)

    token_rows: list[dict[str, Any]] = []
    detected_modes: list[str] = []

    for token in source_tokens:
        roman_token, detected_mode = transliterator.normalise_to_roman(token, payload.inputMode)
        detected_modes.append(detected_mode)

        approved_entry = find_review_entry(token, roman_token, "approved")
        if approved_entry:
            review_segments = approved_entry.get("segments", [])
            segments = normalize_segments_to_roman([item.get("text", "") for item in review_segments]) or [roman_token]
            roles = [item.get("role", "") for item in review_segments]
            for segment_index, segment in enumerate(segments):
                segment_role = roles[segment_index] if segment_index < len(roles) else ""
                segment_display = format_segment_label(segment, segment_role)
                token_display = token if segment_index == 0 else ""
                segment_record = review_segments[segment_index] if segment_index < len(review_segments) else {}
                stored_options = selected_stored_options(segment_record)
                if not stored_options:
                    token_rows.append(make_table_row(
                        token_display=token_display,
                        segment_display=segment_display,
                        lemma="",
                        analysis="Analysis not found",
                        ud_features="_",
                        compound_status="approved",
                        has_analysis=False,
                    ))
                    continue
                for option in stored_options:
                    token_rows.append(row_from_stored_option(
                        token_display=token_display,
                        segment_display=segment_display,
                        option=option,
                        compound_status="approved",
                    ))
                    token_display = ""
            continue

        analysis_targets = [roman_token]
        tamil_analysis_targets = [tamil_for_review(token)]
        rows, _ = analyze_by_priority(
            token,
            roman_token,
            tamil_analysis_targets[0],
        )
        token_rows.extend(rows)

    detected_mode = "mixed" if len(set(detected_modes)) > 1 else (detected_modes[0] if detected_modes else payload.inputMode)
    return {
        "input": normalized_input,
        "detectedMode": detected_mode,
        "tokens": source_tokens,
        "analyses": token_rows,
        "compoundPrompts": [],
        "modelInfo": model_manager.list_enabled_models(),
    }


app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
app.mount("/docs-site", StaticFiles(directory=DOCS_DIR), name="docs-site")


@app.get("/")
def index() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/possible-analyses")
def possible_analyses() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "possible-analyses.html")


@app.get("/documentation")
def documentation() -> FileResponse:
    return FileResponse(DOCS_DIR / "index.html")
