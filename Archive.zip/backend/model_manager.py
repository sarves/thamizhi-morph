from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any


class FomaModelRunner:
    def __init__(self, model: dict[str, Any], project_root: Path):
        self.model = model
        self.project_root = project_root

    def analyze_tokens(self, roman_tokens: list[str]) -> dict[str, Any]:
        analyzer_path = Path(self.model["analyzer_path"])
        if not analyzer_path.is_absolute():
            analyzer_path = self.project_root / analyzer_path

        command = [self.model.get("flookup_path", "flookup"), str(analyzer_path)]
        timeout = int(self.model.get("timeout_seconds", 10))
        input_text = "\n".join(roman_tokens) + "\n"

        try:
            process = subprocess.run(
                command,
                input=input_text,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError:
            return {
                "configured": True,
                "error": f"Flookup executable not found: {command[0]}",
                "raw": "",
                "blocks": [[] for _ in roman_tokens],
            }
        except subprocess.TimeoutExpired:
            return {
                "configured": True,
                "error": f"Foma analysis timed out after {timeout} seconds.",
                "raw": "",
                "blocks": [[] for _ in roman_tokens],
            }

        raw = process.stdout.strip()
        raw_blocks = [
            [line for line in block.splitlines() if line.strip()]
            for block in re.split(r"\n\s*\n", raw)
            if block.strip()
        ]
        blocks = self._pad_blocks(raw_blocks, len(roman_tokens))
        response = {
            "configured": True,
            "raw": raw,
            "blocks": blocks,
            "lines": [line for line in raw.splitlines() if line.strip()],
        }
        if process.returncode != 0:
            response["error"] = process.stderr.strip() or f"Foma exited with code {process.returncode}."
        return response

    @staticmethod
    def _pad_blocks(blocks: list[list[str]], expected: int) -> list[list[str]]:
        if len(blocks) >= expected:
            return blocks[:expected]
        padded = list(blocks)
        while len(padded) < expected:
            padded.append([])
        return padded


class ModelManager:
    def __init__(self, config_path: Path, project_root: Path):
        self.config_path = config_path
        self.project_root = project_root

    def _load_models(
        self,
        stage: str | None = None,
        groups: list[str] | None = None,
        ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        with self.config_path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
        models = [
            {**model, "_config_order": index}
            for index, model in enumerate(config.get("models", []))
            if model.get("enabled", False)
        ]
        if stage is not None:
            models = [model for model in models if model.get("stage", "exact") == stage]
        if groups is not None:
            models = [model for model in models if model.get("group", model.get("id", "")) in groups]
        if ids is not None:
            models = [model for model in models if model.get("id", "") in ids]
        models.sort(key=lambda model: (int(model.get("priority", 1000)), int(model.get("_config_order", 0))))
        return models

    def analyze_tokens(
        self,
        roman_tokens: list[str],
        tamil_tokens: list[str] | None = None,
        stage: str | None = None,
        groups: list[str] | None = None,
        ids: list[str] | None = None,
    ) -> dict[str, Any]:
        models = self._load_models(stage, groups, ids)
        per_model: list[dict[str, Any]] = []
        tamil_tokens = tamil_tokens or roman_tokens
        for model in models:
            input_script = model.get("input_script", "roman")
            model_tokens = tamil_tokens if input_script == "tamil" else roman_tokens
            kind = model.get("kind", "foma")
            if kind != "foma":
                per_model.append({
                    "id": model.get("id", "unknown"),
                    "label": model.get("label", "Unknown Model"),
                    "error": f"Unsupported model kind: {kind}",
                    "blocks": [[] for _ in model_tokens],
                })
                continue

            runner = FomaModelRunner(model, self.project_root)
            result = runner.analyze_tokens(model_tokens)
            result["id"] = model.get("id", "foma_model")
            result["label"] = model.get("label", model.get("id", "Foma Model"))
            result["input_script"] = input_script
            per_model.append(result)

        return {
            "models": per_model,
            "enabled_model_count": len(models),
        }

    def list_enabled_models(self) -> list[dict[str, str]]:
        models = self._load_models()
        return [
            {
                "id": model.get("id", ""),
                "label": model.get("label", model.get("id", "")),
                "kind": model.get("kind", "foma"),
                "stage": model.get("stage", "exact"),
                "group": model.get("group", model.get("id", "")),
                "priority": str(model.get("priority", "")),
            }
            for model in models
        ]

    def analyze_token(
        self,
        roman_token: str,
        tamil_token: str | None = None,
        stage: str | None = None,
        groups: list[str] | None = None,
        ids: list[str] | None = None,
    ) -> dict[str, Any]:
        result = self.analyze_tokens([roman_token], [tamil_token or roman_token], stage=stage, groups=groups, ids=ids)
        model_items = []
        for model in result["models"]:
            block = model.get("blocks", [[]])[0] if model.get("blocks") else []
            model_items.append({
                "id": model.get("id"),
                "label": model.get("label"),
                "lines": block,
                "error": model.get("error"),
            })
        return {"models": model_items}
