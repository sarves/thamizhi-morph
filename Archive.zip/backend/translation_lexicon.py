from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any


class TranslationLexicon:
    def __init__(self, config_path: Path):
        self.config_path = config_path

    def _load(self) -> dict[str, str]:
        suffix = self.config_path.suffix.lower()
        if suffix == ".json":
            with self.config_path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            return {str(key): str(value) for key, value in data.items()}

        if suffix == ".csv":
            mapping: dict[str, str] = {}
            with self.config_path.open("r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                for row in reader:
                    lemma = (row.get("lemma") or "").strip()
                    translation = (row.get("translation") or "").strip()
                    if lemma and translation:
                        mapping[lemma] = translation
            return mapping

        if suffix in {".yaml", ".yml"}:
            try:
                import yaml  # type: ignore
            except ImportError:
                return {}
            with self.config_path.open("r", encoding="utf-8") as handle:
                data: Any = yaml.safe_load(handle) or {}
            if isinstance(data, dict):
                return {str(key): str(value) for key, value in data.items()}
            return {}

        return {}

    def get(self, lemma_tamil: str, lemma_roman: str = "") -> str:
        mapping = self._load()
        return mapping.get(lemma_tamil, "") or mapping.get(lemma_roman, "")
