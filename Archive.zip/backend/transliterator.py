from __future__ import annotations

import json
import unicodedata
from pathlib import Path
from typing import Any


TAMIL_START = "\u0b80"
TAMIL_END = "\u0bff"


class Transliterator:
    def __init__(self, mapping_path: Path):
        self.mapping_path = mapping_path
        self.mapping = self._load_mapping(mapping_path)
        self.virama = self.mapping["virama"]
        self.inherent_vowel = self.mapping["inherentVowel"]
        self.independent_vowels = self.mapping["independentVowels"]
        self.vowel_signs = self.mapping["vowelSigns"]
        self.sign_to_tamil = {value: key for key, value in self.vowel_signs.items()}
        self.vowel_to_tamil = {value: key for key, value in self.independent_vowels.items()}
        self.dead_consonants = self.mapping["consonants"]
        self.base_to_roman = {
            dead.replace(self.virama, ""): roman
            for dead, roman in self.dead_consonants.items()
        }
        self.roman_to_dead = {roman: dead for dead, roman in self.dead_consonants.items()}
        self.roman_consonants = sorted(self.roman_to_dead, key=len, reverse=True)
        self.roman_vowels = sorted(self.vowel_to_tamil, key=len, reverse=True)

    @staticmethod
    def _load_mapping(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    @staticmethod
    def contains_tamil(text: str) -> bool:
        return any(TAMIL_START <= char <= TAMIL_END for char in text)

    @staticmethod
    def normalize_unicode(text: str) -> str:
        return unicodedata.normalize("NFC", text)

    def tamil_to_roman(self, text: str) -> str:
        text = self.normalize_unicode(text)
        output: list[str] = []
        i = 0
        while i < len(text):
            char = text[i]

            if char in self.independent_vowels:
                output.append(self.independent_vowels[char])
                i += 1
                continue

            if char in self.base_to_roman:
                consonant = self.base_to_roman[char]
                next_char = text[i + 1] if i + 1 < len(text) else ""

                if next_char == self.virama:
                    output.append(consonant)
                    i += 2
                    continue

                if next_char in self.vowel_signs:
                    output.append(consonant + self.vowel_signs[next_char])
                    i += 2
                    continue

                output.append(consonant + self.inherent_vowel)
                i += 1
                continue

            if char in self.vowel_signs or char == self.virama:
                i += 1
                continue

            output.append(char)
            i += 1

        return "".join(output)

    def roman_to_tamil(self, text: str) -> str:
        text = self.normalize_unicode(text)
        output: list[str] = []
        i = 0

        while i < len(text):
            consonant = self._match_any(text, i, self.roman_consonants)
            if consonant is not None:
                dead = self.roman_to_dead[consonant]
                base = dead.replace(self.virama, "")
                i += len(consonant)

                vowel = self._match_any(text, i, self.roman_vowels)
                if vowel == self.inherent_vowel:
                    output.append(base)
                    i += len(vowel)
                elif vowel is not None and vowel in self.sign_to_tamil:
                    output.append(base + self.sign_to_tamil[vowel])
                    i += len(vowel)
                else:
                    output.append(dead)
                continue

            vowel = self._match_any(text, i, self.roman_vowels)
            if vowel is not None:
                output.append(self.vowel_to_tamil[vowel])
                i += len(vowel)
                continue

            output.append(text[i])
            i += 1

        return "".join(output)

    @staticmethod
    def _match_any(text: str, index: int, choices: list[str]) -> str | None:
        for choice in choices:
            if text.startswith(choice, index):
                return choice
        return None

    def normalise_to_roman(self, text: str, input_mode: str = "auto") -> tuple[str, str]:
        text = self.normalize_unicode(text)
        if input_mode == "tamil" or (input_mode == "auto" and self.contains_tamil(text)):
            return self.tamil_to_roman(text), "tamil"
        return text, "roman"
