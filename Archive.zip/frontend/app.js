const sourceText = document.querySelector("#sourceText");
const inputMode = document.querySelector("#inputMode");
const analyzeButton = document.querySelector("#analyzeButton");
const clearButton = document.querySelector("#clearButton");
const statusText = document.querySelector("#statusText");
const messageBox = document.querySelector("#messageBox");
const resultsBody = document.querySelector("#resultsBody");

function setMessage(text, kind = "note") {
  if (!text) {
    messageBox.hidden = true;
    messageBox.textContent = "";
    messageBox.className = "message-box";
    return;
  }
  messageBox.hidden = false;
  messageBox.textContent = text;
  messageBox.className = `message-box ${kind}`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function statusTag(item) {
  if (item.status === "Review pending") {
    return '<span class="inline-tag inline-tag-pending">Review Pending</span>';
  }
  if (item.status === "Needs segmentation") {
    return '<span class="inline-tag inline-tag-awaiting">Needs Segmentation</span>';
  }
  if (item.status === "Approved") {
    return '<span class="inline-tag inline-tag-approved">Approved</span>';
  }
  if (item.status === "Not found") {
    return '<span class="inline-tag inline-tag-missing">Not Found</span>';
  }
  return `<span class="inline-tag inline-tag-ok">${escapeHtml(item.status || "Analyzed")}</span>`;
}

function renderRows(analyses) {
  resultsBody.innerHTML = "";
  if (!analyses.length) {
    const row = document.createElement("tr");
    row.innerHTML = '<td colspan="8" class="empty">No analysable tokens were found.</td>';
    resultsBody.appendChild(row);
    return;
  }

  for (const item of analyses) {
    const row = document.createElement("tr");
    const tokenText = item.token === "" ? "" : escapeHtml(item.token || "-");
    row.innerHTML = `
      <td lang="ta">${tokenText}</td>
      <td lang="ta">${escapeHtml(item.segment || "-")}</td>
      <td lang="ta">${escapeHtml(item.lemmaTamil || "-")}</td>
      <td>${escapeHtml(item.lemmaRoman || "-")}</td>
      <td>${escapeHtml(item.lemmaTranslation || "-")}</td>
      <td>${escapeHtml(item.analysis || "Analysis not found")}</td>
      <td>${escapeHtml(item.udFeatures || "_")}</td>
      <td>${statusTag(item)}</td>
    `;
    resultsBody.appendChild(row);
  }
}

async function analyze() {
  const text = sourceText.value.normalize("NFC").trim();
  if (!text) {
    statusText.textContent = "Ready";
    setMessage("Enter Tamil or romanised text first.", "warning");
    renderRows([]);
    return;
  }

  statusText.textContent = "Analyzing...";
  analyzeButton.disabled = true;

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, inputMode: inputMode.value }),
    });
    if (!response.ok) {
      throw new Error(`API returned ${response.status}`);
    }

    const data = await response.json();
    renderRows(data.analyses || []);
    statusText.textContent = "Done";
    setMessage("");
  } catch (error) {
    statusText.textContent = "Error";
    setMessage(error.message, "error");
  } finally {
    analyzeButton.disabled = false;
  }
}

analyzeButton.addEventListener("click", analyze);

clearButton.addEventListener("click", () => {
  sourceText.value = "";
  statusText.textContent = "Ready";
  setMessage("");
  resultsBody.innerHTML = '<tr><td colspan="8" class="empty">Run an analysis to see results.</td></tr>';
});

sourceText.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
    analyze();
  }
});

analyze();
