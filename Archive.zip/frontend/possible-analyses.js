const sourceText = document.querySelector("#sourceText");
const inputMode = document.querySelector("#inputMode");
const suggestButton = document.querySelector("#suggestButton");
const clearButton = document.querySelector("#clearButton");
const statusText = document.querySelector("#statusText");
const messageBox = document.querySelector("#messageBox");
const compoundPromptBox = document.querySelector("#compoundPromptBox");
const pendingBox = document.querySelector("#pendingBox");

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setMessage(text, kind = "note") {
  if (!text) {
    messageBox.hidden = true;
    messageBox.textContent = "";
    messageBox.className = "message-box";
    return;
  }
  messageBox.hidden = false;
  messageBox.textContent = text;
  messageBox.className = `message-box ${kind}`;
}

function renderSuggestions(suggestions) {
  compoundPromptBox.innerHTML = "";
  if (!suggestions.length) {
    compoundPromptBox.innerHTML = '<p class="empty-note">No tokens found.</p>';
    return;
  }

  for (const prompt of suggestions) {
    const card = document.createElement("div");
    card.className = "prompt-card";
    const defaultSegmentation = (prompt.defaultSegments || [prompt.token]).join("+");
    const defaultRoles = (prompt.defaultRoles || []).join("+");
    const status = prompt.status || "new";
    card.innerHTML = `
      <div class="prompt-header">
        <div>
          <p class="prompt-label">Compound candidate</p>
          <p class="prompt-token" lang="ta">${escapeHtml(prompt.token)}</p>
        </div>
        <span class="inline-tag ${status === "approved" ? "inline-tag-approved" : "inline-tag-awaiting"}">${escapeHtml(status)}</span>
      </div>
      <div class="suggested-breakdown" lang="ta">${escapeHtml((prompt.defaultSegments || [prompt.token]).join(" + "))}</div>
      <label>Editable breakdown</label>
      <input class="prompt-input segmentation-input" value="${escapeHtml(defaultSegmentation)}" />
      <label>Roles</label>
      <input class="prompt-input roles-input" value="${escapeHtml(defaultRoles)}" placeholder="verb+aux+suffix" />
      <button type="button" class="submit-compound-button">Submit For Admin Review</button>
    `;

    const segmentationInput = card.querySelector(".segmentation-input");
    const rolesInput = card.querySelector(".roles-input");
    const submitButton = card.querySelector(".submit-compound-button");
    submitButton.addEventListener("click", async () => {
      submitButton.disabled = true;
      try {
        const response = await fetch("/api/compound/submit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            compound: prompt.tokenRoman,
            segmentation: segmentationInput.value.trim(),
            roles: rolesInput.value.trim(),
            sourceToken: prompt.token,
            inputMode: "roman",
            defaultSegmentation,
          }),
        });
        const data = await response.json();
        if (!response.ok || !data.ok) {
          throw new Error(data.message || `Submit failed (${response.status})`);
        }
        setMessage(data.message || "Compound segmentation stored for review.");
        await loadPending();
      } catch (error) {
        setMessage(error.message, "error");
      } finally {
        submitButton.disabled = false;
      }
    });

    compoundPromptBox.appendChild(card);
  }
}

function renderPending(items) {
  pendingBox.innerHTML = "";
  if (!items.length) {
    pendingBox.innerHTML = '<p class="empty-note">No pending items.</p>';
    return;
  }

  for (const item of items) {
    const card = document.createElement("div");
    card.className = "prompt-card";
    const parts = (item.segments || [])
      .map((segment) => `${segment.text}${segment.role ? ` (${segment.role})` : ""}`)
      .join(" + ");
    const options = (item.segments || [])
      .map((segment, segmentIndex) => {
        const analyses = (segment.analysisOptions || [])
          .map((option) => `
            <option value="${escapeHtml(option.index)}" ${segment.selectedAnalysis === option.index ? "selected" : ""}>
              ${escapeHtml(option.index)}: ${escapeHtml(option.lemma)} - ${escapeHtml(option.analysis)}
            </option>
          `)
          .join("");
        return `
          <div class="segment-options">
            <strong lang="ta">${escapeHtml(segment.text)}</strong>
            <select class="analysis-select" data-segment-index="${escapeHtml(segmentIndex)}">
              <option value="">No selected analysis</option>
              ${analyses}
            </select>
          </div>
        `;
      })
      .join("");
    card.innerHTML = `
      <div class="prompt-header">
        <div>
          <p class="prompt-label">Pending approval</p>
          <p class="prompt-token" lang="ta">${escapeHtml(item.compound)}</p>
        </div>
        <span class="inline-tag inline-tag-pending">Review Pending</span>
      </div>
      <div class="suggested-breakdown" lang="ta">${escapeHtml(parts)}</div>
      ${options}
      <button type="button" class="approve-compound-button">Approve Compound</button>
    `;
    const approveButton = card.querySelector(".approve-compound-button");
    approveButton.addEventListener("click", async () => {
      approveButton.disabled = true;
      try {
        const selectedAnalyses = Array.from(card.querySelectorAll(".analysis-select"))
          .map((select) => select.value === "" ? null : Number(select.value));
        const response = await fetch("/api/compound/approve", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            compound: item.compound,
            approvedBy: "admin",
            selectedAnalyses,
          }),
        });
        const data = await response.json();
        if (!response.ok || !data.ok) {
          throw new Error(data.message || `Approve failed (${response.status})`);
        }
        setMessage(data.message || "Compound approved.");
        await loadPending();
      } catch (error) {
        setMessage(error.message, "error");
      } finally {
        approveButton.disabled = false;
      }
    });
    pendingBox.appendChild(card);
  }
}

async function showSuggestions() {
  const text = sourceText.value.normalize("NFC").trim();
  if (!text) {
    setMessage("Enter Tamil or romanised text first.", "warning");
    return;
  }

  statusText.textContent = "Preparing...";
  suggestButton.disabled = true;
  try {
    const response = await fetch("/api/compound/suggest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, inputMode: inputMode.value }),
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(`API returned ${response.status}`);
    }
    renderSuggestions(data.suggestions || []);
    setMessage("");
    statusText.textContent = "Ready";
  } catch (error) {
    statusText.textContent = "Error";
    setMessage(error.message, "error");
  } finally {
    suggestButton.disabled = false;
  }
}

async function loadPending() {
  const response = await fetch("/api/compound/pending");
  const data = await response.json();
  renderPending(data.pending || []);
}

suggestButton.addEventListener("click", showSuggestions);
clearButton.addEventListener("click", () => {
  sourceText.value = "";
  compoundPromptBox.innerHTML = '<p class="empty-note">Enter text to prepare compound segmentations for review.</p>';
  setMessage("");
  statusText.textContent = "Ready";
});

loadPending();
